package com.rest.api;

import com.rest.api.behavior.Swimmable;
import com.rest.api.utils.Constant;

public class Dolphin extends Animal implements Swimmable {
    public void canSwim() {
        System.out.println(Constant.I_AM_SWIMMING);
    }
}
