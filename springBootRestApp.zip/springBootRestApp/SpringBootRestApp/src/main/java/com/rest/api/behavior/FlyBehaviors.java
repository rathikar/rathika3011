package com.rest.api.behavior;

public interface FlyBehaviors {
    void canFly();
}
