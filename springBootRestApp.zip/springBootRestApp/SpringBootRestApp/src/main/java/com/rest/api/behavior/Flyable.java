package com.rest.api.behavior;

public interface Flyable extends FlyBehaviors {
    void canFly();
}
