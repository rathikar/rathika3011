package com.rest.api;

import com.rest.api.helper.SingHelper;
import com.rest.api.utils.enmus.SoundEnums;

public class Dog extends Mammal {
    public Dog() {
        super((new SingHelper(SoundEnums.DOG)));
    }

    public Dog(SingHelper singHelper) {
        super(singHelper);
    }
}
