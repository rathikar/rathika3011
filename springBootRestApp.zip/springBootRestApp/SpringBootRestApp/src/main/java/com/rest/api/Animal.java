/*
 * *******************************************************
      Author : RATHIKA 
      Date   : 05-SEP-2021
* ******************************************************
                                                                 */
package com.rest.api;

public abstract class Animal {

}
