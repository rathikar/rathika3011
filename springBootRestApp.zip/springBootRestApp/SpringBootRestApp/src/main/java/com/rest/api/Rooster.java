package com.rest.api;

import com.rest.api.helper.LangHelper;
import com.rest.api.helper.SingHelper;
import com.rest.api.utils.enmus.LangEnums;
import com.rest.api.utils.enmus.SoundEnums;

public class Rooster extends Chicken {
    LangHelper languageHelper;
    SingHelper singHelper;
    LangEnums languageEnums;

    public Rooster() {
        this.singHelper = new SingHelper(SoundEnums.ROOSTER);
    }

    public Rooster(LangEnums languageEnums) {
        this.singHelper = new SingHelper(SoundEnums.ROOSTER);
        this.languageEnums = languageEnums;
    }

    @Override
    public void canFly() {
        super.canFly();
    }

    @Override
    public void callSound() {
        String translate = LangHelper.translate(SoundEnums.ROOSTER.getSound(), languageEnums);
        System.out.println(translate);

    }
}
