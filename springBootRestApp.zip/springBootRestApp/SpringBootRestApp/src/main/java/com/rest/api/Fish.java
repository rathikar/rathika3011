package com.rest.api;

import com.rest.api.behavior.BodyType;
import com.rest.api.behavior.Swimmable;
import com.rest.api.utils.Constant;

public class Fish extends Animal implements Swimmable, BodyType {
    public void canSwim() {
        System.out.println(Constant.I_AM_SWIMMING);
    }

    public String bodySize() {
        return null;
    }

    public String bodyColor() {
        return null;
    }
}

