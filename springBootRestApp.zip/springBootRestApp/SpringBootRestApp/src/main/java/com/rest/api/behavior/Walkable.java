package com.rest.api.behavior;

public interface Walkable {
    void canWalk();
}
