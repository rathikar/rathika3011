package com.rest.api;

import com.rest.api.behavior.Flyable;
import com.rest.api.behavior.Swimmable;
import com.rest.api.utils.Constant;
import com.rest.api.utils.enmus.SoundEnums;
import com.rest.api.helper.SingHelper;

public class Duck extends Bird implements Swimmable, Flyable {

    public Duck() {
        super(new SingHelper(SoundEnums.DUCK));
    }

    @Override
    public void canWalk() {
        super.canWalk();
    }

    public void canFly() {
        System.out.println(Constant.I_AM_FLYING);
    }

    public void canSwim() {
        System.out.println(Constant.I_AM_SWIMMING);
    }
}
