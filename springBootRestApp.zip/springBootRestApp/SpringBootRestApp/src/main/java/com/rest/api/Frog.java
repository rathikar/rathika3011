package com.rest.api;

import com.rest.api.behavior.Speakable;
import com.rest.api.behavior.Swimmable;
import com.rest.api.behavior.Walkable;
import com.rest.api.helper.SingHelper;
import com.rest.api.utils.Constant;
import com.rest.api.utils.enmus.SoundEnums;

public class Frog extends Animal implements Swimmable, Walkable, Speakable {
    SingHelper singHelper;

    public Frog() {
        singHelper = new SingHelper(SoundEnums.DEFAULT);
    }

    public Frog(SingHelper singHelper) {
        this.singHelper = singHelper;
    }

    public void callSound() {
        singHelper.makeSound();
    }

    public void canSwim() {
        System.out.println(Constant.I_AM_SWIMMING);
    }

    public void canWalk() {
        System.out.println(Constant.I_AM_WALKING);
    }
}
