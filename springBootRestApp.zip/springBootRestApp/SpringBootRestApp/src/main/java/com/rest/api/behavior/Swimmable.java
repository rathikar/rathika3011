package com.rest.api.behavior;

public interface Swimmable {
    void canSwim();
}
