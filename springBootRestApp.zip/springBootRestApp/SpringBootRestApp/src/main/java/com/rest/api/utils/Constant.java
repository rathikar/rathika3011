package com.rest.api.utils;

public class Constant {
	
    public static final String I_AM_WALKING = "I am walking";
    public static final String I_AM_FLYING = "I am flying";
    public static final String I_AM_SWIMMING = "I am swimming";
    public static final String I_MAKE_JOKES = "I make jokes";
    public static final String I_EAT_FISH = "I eat fish";
    public static final String I_CANT_FLY = "I cant Fly";


}
