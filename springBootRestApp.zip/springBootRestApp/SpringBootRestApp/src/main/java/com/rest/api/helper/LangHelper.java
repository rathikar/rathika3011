package com.rest.api.helper;

import com.rest.api.utils.enmus.LangEnums;
import com.rest.api.utils.enmus.SoundEnums;

public class LangHelper {
	 public static String translate(String sound, LangEnums translateTo) {

	        if (translateTo == null || !sound.equals(SoundEnums.ROOSTER.getSound())) {
	            System.out.println("Unable to translate sound: " + sound);
	            return sound;
	        }

	        switch (translateTo) {
	            case DANISH:
	                return LangEnums.DANISH.getLanguage();
	            case DUTCH:
	                return LangEnums.DUTCH.getLanguage();
	            case FINNISH:
	                return LangEnums.FINNISH.getLanguage();
	            case FRENCH:
	                return LangEnums.FRENCH.getLanguage();
	            case GERMAN:
	                return LangEnums.GERMAN.getLanguage();
	            case GREEK:
	                return LangEnums.GREEK.getLanguage();
	            case HEBREW:
	                return LangEnums.HEBREW.getLanguage();
	            case HUNGARIAN:
	                return LangEnums.HUNGARIAN.getLanguage();
	            case ITALIAN:
	                return LangEnums.ITALIAN.getLanguage();
	            case JAPANESE:
	                return LangEnums.JAPANESE.getLanguage();
	            case PORTUGUESE:
	                return LangEnums.PORTUGUESE.getLanguage();
	            case RUSSIAN:
	                return LangEnums.RUSSIAN.getLanguage();
	            case SWEDISH:
	                return LangEnums.SWEDISH.getLanguage();
	            case TURKISH:
	                return LangEnums.TURKISH.getLanguage();
	            case URDU:
	                return LangEnums.URDU.getLanguage();
	            default:
	                System.out.println("Unable to translate to: " + translateTo);
	                return sound;
	        }

	    }


}
