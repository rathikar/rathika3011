package com.rest.api.behavior;

public interface NotFlyable extends FlyBehaviors {
    void canFly();
}

