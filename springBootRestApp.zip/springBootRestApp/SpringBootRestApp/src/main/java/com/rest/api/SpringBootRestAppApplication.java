/*
 * *******************************************************
      Author : RATHIKA 
      Date   : 05-SEP-2021
* ******************************************************
                                                                 */
package com.rest.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRestAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRestAppApplication.class, args);
	}

}
