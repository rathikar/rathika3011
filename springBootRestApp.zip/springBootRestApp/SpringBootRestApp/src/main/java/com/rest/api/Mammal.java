package com.rest.api;

import com.rest.api.behavior.Speakable;
import com.rest.api.behavior.Walkable;
import com.rest.api.helper.SingHelper;
import com.rest.api.utils.Constant;
import com.rest.api.utils.enmus.SoundEnums;

public abstract class Mammal extends Animal implements Walkable, Speakable {
    private SingHelper singHelper;

    public Mammal() {
        this.singHelper = new SingHelper(SoundEnums.DEFAULT);
    }

    public Mammal(SingHelper singHelper) {
        this.singHelper = singHelper;
    }

    public void callSound() {
        singHelper.makeSound();
    }

    public void canWalk() {
        System.out.println(Constant.I_AM_WALKING);
    }
}

