/*
 * *******************************************************
      Author : RATHIKA 
      Date   : 05-SEP-2021
* ******************************************************
                                                                 */
package com.rest.api;

import com.rest.api.behavior.Flyable;
import com.rest.api.behavior.Speakable;
import com.rest.api.behavior.Walkable;
import com.rest.api.helper.SingHelper;
import com.rest.api.utils.Constant;
import com.rest.api.utils.enmus.SoundEnums;

public class Bird extends Animal implements Walkable, Speakable, Flyable {

    private SingHelper singHelper;

    public Bird() {
        this.singHelper = new SingHelper(SoundEnums.DEFAULT);
    }

    public Bird(SingHelper singHelper) {
        this.singHelper = singHelper;
    }

    public void callSound() {
        singHelper.makeSound();
    }

    public void canWalk() {
        System.out.println(Constant.I_AM_WALKING);
    }


    public void canFly() {
        System.out.println(Constant.I_AM_FLYING);
    }
}

