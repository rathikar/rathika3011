package com.rest.api.behavior;

public interface Speakable extends SpeakBehaviors {
    void callSound();
}
