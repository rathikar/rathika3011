package com.rest.api.behavior;

public interface SpeakBehaviors {
    void callSound();
}
