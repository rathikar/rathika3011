package com.rest.api.behavior;

public interface BodyType {
    String bodySize();

    String bodyColor();
}
