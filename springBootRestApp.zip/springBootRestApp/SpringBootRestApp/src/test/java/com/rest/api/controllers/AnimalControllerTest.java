/*
 * *******************************************************
      Author : RATHIKA 
      Date   : 05-SEP-2021
* ******************************************************
                                                                 */
package com.rest.api.controllers;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.rest.api.Animal;
import com.rest.api.Bird;
import com.rest.api.Butterfly;
import com.rest.api.Cat;
import com.rest.api.Chicken;
import com.rest.api.Clownfish;
import com.rest.api.Dog;
import com.rest.api.Dolphin;
import com.rest.api.Duck;
import com.rest.api.Fish;
import com.rest.api.Frog;
import com.rest.api.Parrot;
import com.rest.api.Rooster;
import com.rest.api.Shark;

public class AnimalControllerTest {
	
	@Test
    void getFlyingAnimalCount() {
        Animal[] animals = new Animal[]{
                new Bird(),
                new Duck(),
                new Chicken(),
                new Rooster(),
                new Parrot(),
                new Fish(),
                new Shark(),
                new Clownfish(),
                new Dolphin(),
                new Frog(),
                new Dog(),
                new Butterfly(),
                new Cat()
        };
        int flyingAnimalCount = new AnimalController().getFlyingAnimalCount(animals);
        assertEquals(flyingAnimalCount, 6);
    }


}
