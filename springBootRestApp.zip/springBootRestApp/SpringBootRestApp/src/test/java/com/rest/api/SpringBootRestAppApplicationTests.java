/*
 * *******************************************************
      Author : RATHIKA 
      Date   : 05-SEP-2021
* ******************************************************
                                                                 */

package com.rest.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
